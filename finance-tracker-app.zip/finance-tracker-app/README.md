# Finance Tracker App

A Flutter mobile app inspired by the dark personal finance UI you shared. It includes:

- balance overview
- accounts and assets summary
- budget view
- expense donut chart
- transaction tables
- local SQLite persistence
- seeded demo data on first launch

## Tech

- Flutter
- Provider
- SQLite (`sqflite`)
- fl_chart

## Run

```bash
flutter pub get
flutter run
```

## Structure

```text
lib/
  main.dart
  models/
  providers/
  screens/
  services/
  theme/
  widgets/
```

## Features

### Balance
- total balance card
- payment accounts
- credit cards
- other assets

### Budget
- monthly expense bars
- category chips with progress
- income section
- goals and planner list

### Reports
- donut chart with expense breakdown
- category list with totals
- profit indicator

### Transactions
- date range header
- grouped tables for expense, income, and transfers
- add transaction dialog
- filter by type

## Notes

- The app seeds demo data into SQLite the first time it launches.
- Colors and layout are tuned to match the reference style, while keeping the code maintainable.
- This is ready for GitHub as a starter repo.

## Suggested GitHub push

```bash
git init
git add .
git commit -m "Initial finance tracker app"
git branch -M main
git remote add origin https://github.com/YOURNAME/finance-tracker-app.git
git push -u origin main
```
