import 'package:flutter_test/flutter_test.dart';
import 'package:finance_tracker_app/main.dart';

void main() {
  testWidgets('app renders', (tester) async {
    await tester.pumpWidget(const FinanceTrackerApp());
    expect(find.text('Balance'), findsWidgets);
  });
}
