import 'package:flutter/material.dart';

import '../models/finance_models.dart';
import '../services/database_service.dart';

class FinanceProvider extends ChangeNotifier {
  final DatabaseService _db = DatabaseService.instance;

  bool _loading = true;
  List<FinanceAccount> _accounts = [];
  List<FinanceTransaction> _transactions = [];

  bool get isLoading => _loading;
  List<FinanceAccount> get accounts => _accounts;
  List<FinanceTransaction> get transactions => _transactions;

  Future<void> load() async {
    _loading = true;
    notifyListeners();
    _accounts = await _db.getAccounts();
    _transactions = await _db.getTransactions();
    _loading = false;
    notifyListeners();
  }

  Future<void> addTransaction(FinanceTransaction transaction) async {
    await _db.addTransaction(transaction);
    await load();
  }

  List<FinanceAccount> accountsByGroup(AccountGroup group) {
    return _accounts.where((a) => a.group == group).toList();
  }

  double totalForGroup(AccountGroup group) {
    return accountsByGroup(group).fold(0, (sum, item) => sum + item.balance);
  }

  double get totalIncome => _transactions
      .where((t) => t.type == TransactionType.income)
      .fold(0, (sum, t) => sum + t.amount);

  double get totalExpense => _transactions
      .where((t) => t.type == TransactionType.expense)
      .fold(0, (sum, t) => sum + t.amount);

  double get totalBalance =>
      totalForGroup(AccountGroup.payment) + totalForGroup(AccountGroup.asset) + totalForGroup(AccountGroup.creditCard);

  double get profit => totalIncome - totalExpense;

  List<CategorySummary> get categorySummaries {
    const budgetMap = {
      'Travelling': 10000.0,
      'Education': 1000.0,
      'Cafe': 900.0,
      'Clothing': 1400.0,
      'Home': 1500.0,
      'Car': 200.0,
      'Utilities': 160.0,
    };

    const iconMap = {
      'Travelling': Icons.flight_takeoff_rounded,
      'Education': Icons.school_rounded,
      'Cafe': Icons.local_cafe_rounded,
      'Clothing': Icons.checkroom_rounded,
      'Home': Icons.home_rounded,
      'Car': Icons.directions_car_filled_outlined,
      'Utilities': Icons.electrical_services_rounded,
    };

    final spendMap = <String, double>{};
    for (final tx in _transactions.where((t) => t.type == TransactionType.expense)) {
      spendMap.update(tx.category, (value) => value + tx.amount, ifAbsent: () => tx.amount);
    }

    return spendMap.entries.map((entry) {
      return CategorySummary(
        category: entry.key,
        spent: entry.value,
        budget: budgetMap[entry.key] ?? entry.value,
        icon: iconMap[entry.key] ?? Icons.category_outlined,
      );
    }).toList()
      ..sort((a, b) => b.spent.compareTo(a.spent));
  }

  List<GoalItem> get goals => const [
        GoalItem(title: 'No debt', current: 95309, target: 95309, subtitle: 'Last 30 days +1,462'),
        GoalItem(title: 'Yacht', current: 56188.23, target: 180000, subtitle: 'Last 30 days +11,141.5'),
      ];

  List<FinanceTransaction> transactionsByType(TransactionType type) {
    return _transactions.where((t) => t.type == type).toList();
  }

  List<double> get monthlyExpenses {
    final now = DateTime.now();
    final values = List<double>.filled(8, 0);
    for (final tx in _transactions.where((t) => t.type == TransactionType.expense)) {
      final diff = now.month - tx.date.month + ((now.year - tx.date.year) * 12);
      if (diff >= 0 && diff < values.length) {
        values[values.length - diff - 1] += tx.amount;
      }
    }
    return values;
  }
}
