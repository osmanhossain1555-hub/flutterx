import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'section_card.dart';

class MonthBarChart extends StatelessWidget {
  final List<double> values;
  const MonthBarChart({super.key, required this.values});

  @override
  Widget build(BuildContext context) {
    final maxValue = values.isEmpty ? 1.0 : values.reduce((a, b) => a > b ? a : b);
    const labels = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A'];
    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Budget', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          SizedBox(
            height: 110,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(values.length, (index) {
                final ratio = maxValue == 0 ? 0.0 : values[index] / maxValue;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          height: 90 * ratio.clamp(0.08, 1.0),
                          decoration: BoxDecoration(
                            color: index == values.length - 3 ? AppTheme.yellow : AppTheme.cyan,
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(labels[index % labels.length], style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
