import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/finance_models.dart';
import '../theme/app_theme.dart';
import 'section_card.dart';

class TransactionsTable extends StatelessWidget {
  final String title;
  final List<FinanceTransaction> transactions;
  const TransactionsTable({super.key, required this.title, required this.transactions});

  String money(num value) => NumberFormat.currency(symbol: '\$', decimalDigits: 2).format(value);
  String date(DateTime dt) => DateFormat('M/d/yy').format(dt);

  @override
  Widget build(BuildContext context) {
    final total = transactions.fold<double>(0, (sum, tx) => sum + tx.amount);
    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
            decoration: BoxDecoration(
              color: AppTheme.panel2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.cardBorder),
            ),
            child: const Row(
              children: [
                Expanded(flex: 2, child: Text('Date', style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary))),
                Expanded(flex: 3, child: Text('Category', style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary))),
                Expanded(flex: 3, child: Text('Account', style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary))),
                Expanded(flex: 2, child: Text('Amount', textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary))),
              ],
            ),
          ),
          const SizedBox(height: 8),
          ...transactions.map(
            (tx) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                children: [
                  Expanded(flex: 2, child: Text(date(tx.date))),
                  Expanded(flex: 3, child: Text(tx.category)),
                  Expanded(flex: 3, child: Text(tx.accountName, style: const TextStyle(color: AppTheme.textSecondary))),
                  Expanded(flex: 2, child: Text(money(tx.amount), textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700))),
                ],
              ),
            ),
          ),
          const Divider(color: AppTheme.cardBorder),
          Row(
            children: [
              const Expanded(child: Text('TOTAL', style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary))),
              Text(money(total), style: const TextStyle(fontWeight: FontWeight.w700)),
            ],
          ),
        ],
      ),
    );
  }
}
