import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/finance_models.dart';
import '../theme/app_theme.dart';
import 'section_card.dart';

class ExpenseDonutChart extends StatelessWidget {
  final List<CategorySummary> categories;
  final double centerValue;
  const ExpenseDonutChart({super.key, required this.categories, required this.centerValue});

  static const _colors = [
    Color(0xFF18D7A8),
    Color(0xFFB5E61D),
    Color(0xFFF4C911),
    Color(0xFFFF9B0A),
    Color(0xFF4CD0FF),
    Color(0xFF06A7FF),
    Color(0xFF8D76FF),
  ];

  String money(num value) => NumberFormat.currency(symbol: '\$', decimalDigits: 2).format(value);

  @override
  Widget build(BuildContext context) {
    final total = categories.fold<double>(0, (sum, c) => sum + c.spent);
    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Expenses', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          SizedBox(
            height: 260,
            child: Stack(
              alignment: Alignment.center,
              children: [
                PieChart(
                  PieChartData(
                    centerSpaceRadius: 58,
                    sectionsSpace: 2,
                    sections: List.generate(categories.length, (index) {
                      final category = categories[index];
                      final pct = total == 0 ? 0 : category.spent / total * 100;
                      return PieChartSectionData(
                        color: _colors[index % _colors.length],
                        value: category.spent,
                        title: '${pct.round()}%',
                        radius: 56,
                        titleStyle: const TextStyle(color: Color(0xFF0A2938), fontWeight: FontWeight.bold, fontSize: 12),
                      );
                    }),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(money(centerValue), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    const Text('PROFIT', style: TextStyle(letterSpacing: 1.2, color: AppTheme.textSecondary)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          ...List.generate(categories.length, (index) {
            final category = categories[index];
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Container(width: 12, height: 12, decoration: BoxDecoration(color: _colors[index % _colors.length], borderRadius: BorderRadius.circular(4))),
                  const SizedBox(width: 10),
                  Expanded(child: Text(category.category)),
                  Text(money(category.spent), style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
