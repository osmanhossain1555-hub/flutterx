import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/finance_models.dart';
import '../theme/app_theme.dart';
import 'section_card.dart';

class AccountGroupList extends StatelessWidget {
  final String title;
  final double total;
  final List<FinanceAccount> accounts;
  const AccountGroupList({super.key, required this.title, required this.total, required this.accounts});

  String money(num value) => NumberFormat.currency(symbol: '\$', decimalDigits: value.abs() < 100 ? 2 : 0).format(value);

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(title.toUpperCase(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.textSecondary)),
              const Spacer(),
              Text(money(total), style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary)),
            ],
          ),
          const SizedBox(height: 12),
          ...accounts.map(
            (account) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Icon(account.icon, color: Colors.white70, size: 22),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(account.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 2),
                        Text(
                          money(account.balance),
                          style: TextStyle(
                            color: account.balance < 0 ? AppTheme.yellow : AppTheme.cyan,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
