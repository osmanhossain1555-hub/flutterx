import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/finance_models.dart';
import '../theme/app_theme.dart';
import 'section_card.dart';

class CategoryProgressGrid extends StatelessWidget {
  final List<CategorySummary> categories;
  const CategoryProgressGrid({super.key, required this.categories});

  String money(num value) => NumberFormat.currency(symbol: '\$', decimalDigits: 2).format(value);

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Expenses', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: categories.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              childAspectRatio: 0.92,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemBuilder: (context, index) {
              final category = categories[index];
              return Container(
                decoration: BoxDecoration(
                  color: AppTheme.panel2,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppTheme.cardBorder),
                ),
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: Colors.transparent,
                      child: Container(
                        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppTheme.yellow, width: 2)),
                        child: CircleAvatar(radius: 15, backgroundColor: AppTheme.panel, child: Icon(category.icon, size: 18, color: Colors.white)),
                      ),
                    ),
                    const Spacer(),
                    Text(category.category, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text(money(category.spent), style: const TextStyle(color: AppTheme.yellow, fontWeight: FontWeight.w700)),
                    Text(money(category.budget), style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
