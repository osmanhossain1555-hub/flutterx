import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../theme/app_theme.dart';
import 'section_card.dart';

class BalanceCard extends StatelessWidget {
  final double balance;
  final double highlight;
  const BalanceCard({super.key, required this.balance, required this.highlight});

  String money(num value) => NumberFormat.currency(symbol: '\$', decimalDigits: 2).format(value);

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Balance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              Text('Edit', style: TextStyle(color: Colors.white.withOpacity(0.8))),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 22,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(2),
              color: AppTheme.cyan,
            ),
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(money(balance), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF053346))),
          ),
          const SizedBox(height: 10),
          FractionallySizedBox(
            widthFactor: 0.55,
            child: Container(
              height: 22,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                color: AppTheme.yellow,
              ),
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(money(highlight), style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF463700))),
            ),
          ),
        ],
      ),
    );
  }
}
