import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/finance_models.dart';
import '../theme/app_theme.dart';
import 'section_card.dart';

class GoalsPanel extends StatelessWidget {
  final List<GoalItem> goals;
  final List<FinanceTransaction> plannerItems;
  final double totalIncome;
  final double totalExpense;
  const GoalsPanel({super.key, required this.goals, required this.plannerItems, required this.totalIncome, required this.totalExpense});

  String money(num value) => NumberFormat.currency(symbol: '\$', decimalDigits: value.abs() < 100 ? 0 : 2).format(value);
  String fullDate(DateTime dt) => DateFormat('MMM d').format(dt);

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(DateTime.now().day.toString(), style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w200)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  DateFormat('EEEE\nMMMM yyyy').format(DateTime.now()),
                  style: const TextStyle(fontSize: 16, height: 1.2),
                ),
              ),
              const CircleAvatar(backgroundColor: Colors.transparent, child: Icon(Icons.add_circle_outline, color: Colors.white, size: 34)),
            ],
          ),
          const SizedBox(height: 12),
          const Text('GOALS', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          ...goals.map((goal) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    const CircleAvatar(radius: 14, backgroundColor: Colors.transparent, child: Icon(Icons.adjust_rounded, color: AppTheme.yellow, size: 24)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(goal.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text(goal.subtitle, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                        ],
                      ),
                    ),
                    Text(money(goal.current), style: const TextStyle(color: AppTheme.cyan, fontWeight: FontWeight.w700)),
                  ],
                ),
              )),
          const SizedBox(height: 8),
          const Text('PLANNED', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          ...plannerItems.take(3).map((tx) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    const CircleAvatar(radius: 14, backgroundColor: Colors.transparent, child: Icon(Icons.schedule, color: Colors.white70, size: 22)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(tx.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text(fullDate(tx.date), style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: tx.type == TransactionType.expense ? AppTheme.yellow : AppTheme.cyan,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        money(tx.amount),
                        style: TextStyle(
                          color: tx.type == TransactionType.expense ? const Color(0xFF463700) : const Color(0xFF053346),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('TOTAL EXPENSES: ${money(totalExpense)}', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                Text('TOTAL INCOMES: ${money(totalIncome)}', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
