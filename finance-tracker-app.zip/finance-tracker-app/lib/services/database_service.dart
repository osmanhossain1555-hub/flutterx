import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/finance_models.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'finance_tracker.db');

    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            balance REAL NOT NULL,
            groupName TEXT NOT NULL,
            iconCodePoint INTEGER NOT NULL,
            fontFamily TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE transactions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            accountName TEXT NOT NULL,
            amount REAL NOT NULL,
            date TEXT NOT NULL,
            typeName TEXT NOT NULL,
            note TEXT
          )
        ''');

        await _seedDemoData(db);
      },
    );
  }

  Future<void> _seedDemoData(Database db) async {
    final accounts = <FinanceAccount>[
      const FinanceAccount(name: 'Cash Euro', balance: 2372.97, group: AccountGroup.payment, icon: Icons.euro),
      const FinanceAccount(name: 'Money Pro Bank', balance: 17479, group: AccountGroup.payment, icon: Icons.account_balance_wallet_outlined),
      const FinanceAccount(name: 'National Bank', balance: 15410, group: AccountGroup.payment, icon: Icons.account_balance_outlined),
      const FinanceAccount(name: 'Cash', balance: 4020, group: AccountGroup.payment, icon: Icons.payments_outlined),
      const FinanceAccount(name: 'Money Pro Bank', balance: -5031, group: AccountGroup.creditCard, icon: Icons.credit_card),
      const FinanceAccount(name: 'National Bank', balance: 340, group: AccountGroup.creditCard, icon: Icons.credit_card_outlined),
      const FinanceAccount(name: 'Bike', balance: 1000, group: AccountGroup.asset, icon: Icons.pedal_bike_outlined),
      const FinanceAccount(name: 'Motorbike', balance: 14400, group: AccountGroup.asset, icon: Icons.two_wheeler_outlined),
      const FinanceAccount(name: 'Parking Place', balance: 8900, group: AccountGroup.asset, icon: Icons.local_parking_outlined),
      const FinanceAccount(name: 'Car', balance: 50000, group: AccountGroup.asset, icon: Icons.directions_car_outlined),
    ];

    for (final account in accounts) {
      await db.insert('accounts', account.toMap());
    }

    final now = DateTime.now();
    final transactions = <FinanceTransaction>[
      FinanceTransaction(title: 'Salary', category: 'Salary', accountName: 'Money Pro Bank', amount: 6000, date: DateTime(now.year, now.month, 1), type: TransactionType.income),
      FinanceTransaction(title: 'Business income', category: 'Business', accountName: 'Money Pro Bank', amount: 3600, date: DateTime(now.year, now.month, 7), type: TransactionType.income),
      FinanceTransaction(title: 'Interest income', category: 'Interest', accountName: 'National Bank', amount: 400, date: DateTime(now.year, now.month, 15), type: TransactionType.income),
      FinanceTransaction(title: 'Travelling', category: 'Travelling', accountName: 'Money Pro Bank', amount: 10800, date: DateTime(now.year, now.month, 3), type: TransactionType.expense),
      FinanceTransaction(title: 'Education', category: 'Education', accountName: 'Money Pro Bank', amount: 1000, date: DateTime(now.year, now.month, 9), type: TransactionType.expense),
      FinanceTransaction(title: 'Cafe', category: 'Cafe', accountName: 'Money Pro Bank', amount: 900, date: DateTime(now.year, now.month, 11), type: TransactionType.expense),
      FinanceTransaction(title: 'Clothing', category: 'Clothing', accountName: 'Money Pro Bank', amount: 738, date: DateTime(now.year, now.month, 13), type: TransactionType.expense),
      FinanceTransaction(title: 'Home', category: 'Home', accountName: 'National Bank', amount: 650, date: DateTime(now.year, now.month, 17), type: TransactionType.expense),
      FinanceTransaction(title: 'Car', category: 'Car', accountName: 'Money Pro Bank', amount: 247, date: DateTime(now.year, now.month, 18), type: TransactionType.expense),
      FinanceTransaction(title: 'Utilities', category: 'Utilities', accountName: 'National Bank', amount: 120, date: DateTime(now.year, now.month, 19), type: TransactionType.expense),
      FinanceTransaction(title: 'Money Transfer', category: 'Transfer', accountName: 'Money Pro Bank', amount: 2200, date: DateTime(now.year, now.month, 21), type: TransactionType.transfer),
    ];

    for (final tx in transactions) {
      await db.insert('transactions', tx.toMap());
    }
  }

  Future<List<FinanceAccount>> getAccounts() async {
    final db = await database;
    final result = await db.query('accounts', orderBy: 'groupName ASC, name ASC');
    return result.map(FinanceAccount.fromMap).toList();
  }

  Future<List<FinanceTransaction>> getTransactions() async {
    final db = await database;
    final result = await db.query('transactions', orderBy: 'date DESC, id DESC');
    return result.map(FinanceTransaction.fromMap).toList();
  }

  Future<void> addTransaction(FinanceTransaction transaction) async {
    final db = await database;
    await db.insert('transactions', transaction.toMap());
  }
}
