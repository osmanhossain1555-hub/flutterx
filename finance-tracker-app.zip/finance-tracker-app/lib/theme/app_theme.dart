import 'package:flutter/material.dart';

class AppTheme {
  static const Color bgStart = Color(0xFF0C2D3E);
  static const Color bgEnd = Color(0xFF081B27);
  static const Color panel = Color(0xFF163646);
  static const Color panel2 = Color(0xFF193C4C);
  static const Color cyan = Color(0xFF29D3F8);
  static const Color yellow = Color(0xFFF6C90E);
  static const Color green = Color(0xFF18D7A8);
  static const Color cardBorder = Color(0x55FFFFFF);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0x99FFFFFF);

  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: bgEnd,
      fontFamily: 'Roboto',
      colorScheme: ColorScheme.fromSeed(seedColor: cyan, brightness: Brightness.dark),
      textTheme: const TextTheme(
        bodyMedium: TextStyle(color: textPrimary),
        bodySmall: TextStyle(color: textSecondary),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        foregroundColor: textPrimary,
        elevation: 0,
      ),
      cardTheme: CardTheme(
        color: panel,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: cardBorder),
        ),
      ),
    );
  }
}
