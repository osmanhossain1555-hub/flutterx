import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/finance_models.dart';
import '../providers/finance_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/account_group_list.dart';
import '../widgets/balance_card.dart';
import '../widgets/gradient_background.dart';

class BalanceScreen extends StatelessWidget {
  const BalanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();

    return GradientBackground(
      child: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const _PageHeader(title: 'Balance'),
                const SizedBox(height: 12),
                BalanceCard(balance: provider.totalBalance, highlight: provider.totalForGroup(AccountGroup.payment)),
                const SizedBox(height: 12),
                AccountGroupList(
                  title: 'Payment Accounts',
                  total: provider.totalForGroup(AccountGroup.payment),
                  accounts: provider.accountsByGroup(AccountGroup.payment),
                ),
                const SizedBox(height: 12),
                AccountGroupList(
                  title: 'Credit Cards',
                  total: provider.totalForGroup(AccountGroup.creditCard),
                  accounts: provider.accountsByGroup(AccountGroup.creditCard),
                ),
                const SizedBox(height: 12),
                AccountGroupList(
                  title: 'Other Assets',
                  total: provider.totalForGroup(AccountGroup.asset),
                  accounts: provider.accountsByGroup(AccountGroup.asset),
                ),
              ],
            ),
    );
  }
}

class _PageHeader extends StatelessWidget {
  final String title;
  const _PageHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.ios_share_outlined, color: AppTheme.textSecondary),
        const Spacer(),
        Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        const Spacer(),
        const Text('Edit', style: TextStyle(color: AppTheme.textSecondary)),
      ],
    );
  }
}
