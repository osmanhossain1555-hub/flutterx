import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/finance_models.dart';
import '../providers/finance_provider.dart';
import '../theme/app_theme.dart';

class AddTransactionSheet extends StatefulWidget {
  const AddTransactionSheet({super.key});

  @override
  State<AddTransactionSheet> createState() => _AddTransactionSheetState();
}

class _AddTransactionSheetState extends State<AddTransactionSheet> {
  final _titleController = TextEditingController();
  final _categoryController = TextEditingController();
  final _accountController = TextEditingController(text: 'Money Pro Bank');
  final _amountController = TextEditingController();
  TransactionType _type = TransactionType.expense;

  @override
  void dispose() {
    _titleController.dispose();
    _categoryController.dispose();
    _accountController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final amount = double.tryParse(_amountController.text.trim());
    if (_titleController.text.trim().isEmpty || _categoryController.text.trim().isEmpty || amount == null) {
      return;
    }

    await context.read<FinanceProvider>().addTransaction(
          FinanceTransaction(
            title: _titleController.text.trim(),
            category: _categoryController.text.trim(),
            accountName: _accountController.text.trim(),
            amount: amount,
            date: DateTime.now(),
            type: _type,
          ),
        );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      decoration: const BoxDecoration(
        color: AppTheme.panel,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Center(child: Text('Add Transaction', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
            const SizedBox(height: 16),
            _field(_titleController, 'Title'),
            const SizedBox(height: 10),
            _field(_categoryController, 'Category'),
            const SizedBox(height: 10),
            _field(_accountController, 'Account'),
            const SizedBox(height: 10),
            _field(_amountController, 'Amount', keyboardType: const TextInputType.numberWithOptions(decimal: true)),
            const SizedBox(height: 10),
            DropdownButtonFormField<TransactionType>(
              value: _type,
              dropdownColor: AppTheme.panel2,
              decoration: _decoration('Type'),
              items: TransactionType.values
                  .map((type) => DropdownMenuItem(value: type, child: Text(type.name)))
                  .toList(),
              onChanged: (value) => setState(() => _type = value ?? TransactionType.expense),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _save,
                style: FilledButton.styleFrom(backgroundColor: AppTheme.cyan, foregroundColor: const Color(0xFF053346)),
                child: const Text('Save'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, {TextInputType? keyboardType}) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: _decoration(label),
    );
  }

  InputDecoration _decoration(String label) => InputDecoration(
        labelText: label,
        filled: true,
        fillColor: AppTheme.panel2,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      );
}
