import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/finance_models.dart';
import '../providers/finance_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/gradient_background.dart';
import '../widgets/transactions_table.dart';

class TransactionsScreen extends StatelessWidget {
  const TransactionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();
    return GradientBackground(
      child: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    const Icon(Icons.arrow_back_ios_new, size: 18),
                    const Spacer(),
                    const Text('Transactions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    const Icon(Icons.ios_share_outlined, size: 18),
                    const SizedBox(width: 14),
                    const Icon(Icons.filter_alt_outlined, size: 18),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppTheme.panel,
                    border: Border.all(color: AppTheme.cardBorder),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      Expanded(child: _DateChip(label: 'Begin', value: DateFormat('MMM d, yyyy').format(DateTime(DateTime.now().year, DateTime.now().month, 1)))),
                      const SizedBox(width: 10),
                      Expanded(child: _DateChip(label: 'End', value: DateFormat('MMM d, yyyy').format(DateTime.now()))),
                      const SizedBox(width: 10),
                      const Icon(Icons.more_horiz, color: Colors.white70),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                TransactionsTable(title: 'Expense', transactions: provider.transactionsByType(TransactionType.expense)),
                const SizedBox(height: 12),
                TransactionsTable(title: 'Income', transactions: provider.transactionsByType(TransactionType.income)),
                const SizedBox(height: 12),
                TransactionsTable(title: 'Money Transfer', transactions: provider.transactionsByType(TransactionType.transfer)),
              ],
            ),
    );
  }
}

class _DateChip extends StatelessWidget {
  final String label;
  final String value;
  const _DateChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: AppTheme.panel2,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
          const SizedBox(height: 2),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
