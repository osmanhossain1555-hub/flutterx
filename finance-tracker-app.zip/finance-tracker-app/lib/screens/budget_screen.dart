import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../providers/finance_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/category_progress_grid.dart';
import '../widgets/goals_panel.dart';
import '../widgets/gradient_background.dart';
import '../widgets/month_bar_chart.dart';
import '../widgets/section_card.dart';

class BudgetScreen extends StatelessWidget {
  const BudgetScreen({super.key});

  String money(num value) => NumberFormat.currency(symbol: '\$', decimalDigits: 2).format(value);

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();

    return GradientBackground(
      child: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    Text(DateFormat('MMM yyyy').format(DateTime.now()), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    const Icon(Icons.keyboard_arrow_down),
                    const Spacer(),
                    const Text('Edit', style: TextStyle(color: AppTheme.textSecondary)),
                  ],
                ),
                const SizedBox(height: 12),
                MonthBarChart(values: provider.monthlyExpenses),
                const SizedBox(height: 12),
                CategoryProgressGrid(categories: provider.categorySummaries),
                const SizedBox(height: 12),
                SectionCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Income', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _IncomeBadge(title: 'Salary', amount: 6000),
                          const SizedBox(width: 10),
                          _IncomeBadge(title: 'Business', amount: 3600),
                          const SizedBox(width: 10),
                          _IncomeBadge(title: 'Interest', amount: 400),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Text('TOTAL', style: TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w700)),
                          const Spacer(),
                          Text('${money(provider.totalExpense)} / ${money(provider.totalIncome)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                GoalsPanel(
                  goals: provider.goals,
                  plannerItems: provider.transactions,
                  totalIncome: provider.totalIncome,
                  totalExpense: provider.totalExpense,
                ),
              ],
            ),
    );
  }
}

class _IncomeBadge extends StatelessWidget {
  final String title;
  final double amount;
  const _IncomeBadge({required this.title, required this.amount});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppTheme.panel2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.cardBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(NumberFormat.currency(symbol: '\$', decimalDigits: 2).format(amount), style: const TextStyle(color: AppTheme.cyan, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
