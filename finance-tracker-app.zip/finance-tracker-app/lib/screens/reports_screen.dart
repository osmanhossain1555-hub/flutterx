import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/finance_provider.dart';
import '../widgets/expense_donut_chart.dart';
import '../widgets/gradient_background.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<FinanceProvider>();
    return GradientBackground(
      child: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const SizedBox(height: 4),
                ExpenseDonutChart(
                  categories: provider.categorySummaries,
                  centerValue: provider.profit,
                ),
              ],
            ),
    );
  }
}
