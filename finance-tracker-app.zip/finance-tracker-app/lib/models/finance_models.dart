import 'package:flutter/material.dart';

enum TransactionType { income, expense, transfer }
enum AccountGroup { payment, creditCard, asset }

class FinanceAccount {
  final int? id;
  final String name;
  final double balance;
  final AccountGroup group;
  final IconData icon;

  const FinanceAccount({
    this.id,
    required this.name,
    required this.balance,
    required this.group,
    required this.icon,
  });

  FinanceAccount copyWith({
    int? id,
    String? name,
    double? balance,
    AccountGroup? group,
    IconData? icon,
  }) {
    return FinanceAccount(
      id: id ?? this.id,
      name: name ?? this.name,
      balance: balance ?? this.balance,
      group: group ?? this.group,
      icon: icon ?? this.icon,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'balance': balance,
        'groupName': group.name,
        'iconCodePoint': icon.codePoint,
        'fontFamily': icon.fontFamily,
      };

  factory FinanceAccount.fromMap(Map<String, dynamic> map) {
    return FinanceAccount(
      id: map['id'] as int?,
      name: map['name'] as String,
      balance: (map['balance'] as num).toDouble(),
      group: AccountGroup.values.firstWhere(
        (e) => e.name == map['groupName'],
      ),
      icon: IconData(
        map['iconCodePoint'] as int,
        fontFamily: map['fontFamily'] as String? ?? 'MaterialIcons',
      ),
    );
  }
}

class FinanceTransaction {
  final int? id;
  final String title;
  final String category;
  final String accountName;
  final double amount;
  final DateTime date;
  final TransactionType type;
  final String? note;

  const FinanceTransaction({
    this.id,
    required this.title,
    required this.category,
    required this.accountName,
    required this.amount,
    required this.date,
    required this.type,
    this.note,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'category': category,
        'accountName': accountName,
        'amount': amount,
        'date': date.toIso8601String(),
        'typeName': type.name,
        'note': note,
      };

  factory FinanceTransaction.fromMap(Map<String, dynamic> map) {
    return FinanceTransaction(
      id: map['id'] as int?,
      title: map['title'] as String,
      category: map['category'] as String,
      accountName: map['accountName'] as String,
      amount: (map['amount'] as num).toDouble(),
      date: DateTime.parse(map['date'] as String),
      type: TransactionType.values.firstWhere(
        (e) => e.name == map['typeName'],
      ),
      note: map['note'] as String?,
    );
  }
}

class CategorySummary {
  final String category;
  final double spent;
  final double budget;
  final IconData icon;

  const CategorySummary({
    required this.category,
    required this.spent,
    required this.budget,
    required this.icon,
  });

  double get progress => budget == 0 ? 0 : (spent / budget).clamp(0, 1);
}

class GoalItem {
  final String title;
  final double current;
  final double target;
  final String subtitle;

  const GoalItem({
    required this.title,
    required this.current,
    required this.target,
    required this.subtitle,
  });
}
